﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ExtensionsLibrary
{
    public static class StringExtensions
    {
        /// <summary>
        /// Determine if string is empty
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        public static bool IsNullOrWhiteSpace(this string sender)
        {
            return string.IsNullOrWhiteSpace(sender);
        }
        /// <summary>
        /// Overload of the standard String.Contains method which provides case sensitivity.
        /// </summary>
        /// <param name="sender">String to search</param>
        /// <param name="pSubString">Sub string to match</param>
        /// <param name="pCaseSensitive">Use case or ignore case</param>
        /// <returns></returns>
        public static bool Contains(this string sender, string pSubString, bool pCaseSensitive)
        {
            return pCaseSensitive ? sender.Contains(pSubString) : sender.ToLower().IndexOf(pSubString.ToLower(), 0, StringComparison.Ordinal) >= 0;
        }

        #region These extensions may not be suitable for everyone
        /// <summary>
        /// Convert string value to int, if string is not a valid int return 0.
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        public static int ToInt32(this string sender)
        {
            return sender.IsNullOrWhiteSpace() || (sender == null) == true || sender.IsNumeric() == false ? Convert.ToInt32(0) : Convert.ToInt32(sender);
        }
        /// <summary>
        /// Convert string value to int
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="pThrowExceptionOnFailure"></param>
        /// <returns></returns>
        /// <remarks>
        /// An exception is thrown if conversion fails with pThrowExceptionIfFailed = true.
        /// </remarks> 
        public static int ToInt32(this string sender, bool pThrowExceptionOnFailure = false) 
        {

            var valid = int.TryParse(sender, out var result);
            if (valid) return result;
            if (pThrowExceptionOnFailure)
            {
                throw new FormatException($"'{sender}' cannot be converted as int");
            }

            return result;
        }
        /// <summary>
        /// Convert string value to decimal, if string is not a valid decimal return 0.
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        public static decimal ToDecimal(this string sender)
        {
            return sender.IsNullOrWhiteSpace() || (sender == null) == true || sender.IsNumeric() == false ? 0 : Convert.ToDecimal(sender);
        }

        /// <summary>
        /// Convert string value to bool, if string is not a valid bool return false.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool ToBoolean(this string value)
        {
            try
            {
                return Convert.ToBoolean(value);
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion

        /// <summary>
        /// Determine if string is numeric
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        public static bool IsNumeric(this string sender)
        {
            var regularExpression = new Regex("^-[0-9]+$|^[0-9]+$");

            return regularExpression.Match(sender).Success;
        }

        /// <summary>
        /// Format a string for reading e.g. 976-1234, (333) 444-5555, (933) 344-4555 x5
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        public static string FormatPhoneNumber(this string sender)
        {
            string result = string.Empty;

            if (sender.Contains("(") == false && sender.Contains(")") == false && sender.Contains("-") == false)
            {
                if (sender.Length == 7)
                {
                    result = sender.Substring(0, 3) + "-" + sender.Substring(3, 4);
                }
                else if (sender.Length == 10)
                {
                    result = $"({sender.Substring(0, 3)}) {sender.Substring(3, 3)}-{sender.Substring(6, 4)}";
                }
                else if (sender.Length > 10)
                {

                    result = $"({sender.Substring(0, 3)}) {sender.Substring(3, 3)}-{sender.Substring(6, 4)} x{sender.Substring(10)}";
                }
            }
            else
            {
                result = sender;
            }

            return result;
        }

        /// <summary>
        /// Join string array with " and " as the last delimiter.
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        public static string JoinWithLastSeparator(this string[] sender)
        {
            return string.Join(", ", sender.Take(sender.Length - 1)) + ((((sender.Length <= 1) ? "" : " and ")) + sender.LastOrDefault());
        }
        /// <summary>
        /// Join string array with specified delimiter, " and " for the last delimiter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="pDelimiter"></param>
        /// <returns></returns>
        public static string JoinWithLastSeparator(this string[] sender, string pDelimiter)
        {
            return string.Join(pDelimiter + " ", sender.Take(sender.Length - 1)) + ((((sender.Length <= 1) ? "" : " and ")) + sender.LastOrDefault());
        }
        /// <summary>
        /// Join string array with specified delimiter and last delimiter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="pDelimiter"></param>
        /// <param name="pLastDelimiter"></param>
        /// <returns></returns>
        public static string JoinWithLastSeparator(this string[] sender, string pDelimiter, string pLastDelimiter)
        {
            return string.Join(pDelimiter + " ", sender.Take(sender.Length - 1)) + ((((sender.Length <= 1) ? "" : pLastDelimiter)) + sender.LastOrDefault());
        }
    }
}
