﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionsLibrary
{
    public static class DataTableExtensions
    {
        /// <summary>
        /// Get last column value in this table
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sender"></param>
        /// <param name="pColumnName">Name of column to get value for</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public static T FieldLastValue<T>(this DataTable sender, string pColumnName)
        {
            return sender.Rows[sender.Rows.Count - 1].Field<T>(sender.Columns[pColumnName]);
        }
        /// <summary>
        /// Get last column value in this table
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sender"></param>
        /// <param name="pColumnIndex">Ordinal index of column to get value for.</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public static T FieldLastValue<T>(this DataTable sender, int pColumnIndex)
        {
            return sender.Rows[sender.Rows.Count - 1].Field<T>(sender.Columns[pColumnIndex]);
        }
    }
}
