﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionsLibrary
{
    public static class DataSetExtensions
    {
        /// <summary>
        /// Create a one to many relationship for a master-detail
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="pMaster">Master table</param>
        /// <param name="pChild">Child table of master table</param>
        /// <param name="pMasterKey">Master table primary key</param>
        /// <param name="pChildKey">Child table of master's primary key</param>
        public static void SetRelation(this DataSet sender, string pMaster, string pChild, string pMasterKey, string pChildKey)
        {
            sender.Relations.Add(new DataRelation(string.Concat(pMaster, pChild), sender.Tables[pMaster].Columns[pMasterKey], 
                sender.Tables[pChild].Columns[pChildKey]));
        }

    }
}
