﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionsLibrary
{
    public static class GenericExtensions
    {
        /// <summary>
        /// Determine if T is between lower and upper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="actual"></param>
        /// <param name="lower"></param>
        /// <param name="upper"></param>
        /// <returns></returns>
        public static bool Between<T>(this T actual, T lower, T upper) where T : IComparable<T>
        {
            return actual.CompareTo(lower) >= 0 && actual.CompareTo(upper) < 0;
        }
        /// <summary>
        /// Adds a value uniquely to to a collection and returns a value whether the value was added or not.
        /// </summary>
        /// <typeparam name = "T">The generic collection value type</typeparam>
        /// <param name = "sender">The collection.</param>
        /// <param name = "pValue">The value to be added.</param>
        /// <returns>Indicates whether the value was added or not</returns>
        public static bool AddUnique<T>(this ICollection<T> sender, T pValue)
        {
            var alreadyHas = sender.Contains(pValue);
            if (!alreadyHas)
            {
                sender.Add(pValue);
            }
            return alreadyHas;
        }
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> sender, Func<TSource, TKey> pKeySelector)
        {
            var hKeys = new HashSet<TKey>();
            return sender.Where((element) => hKeys.Add(pKeySelector(element)));
        }

    }
}
